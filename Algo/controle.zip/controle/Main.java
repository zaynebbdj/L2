import base_tp_note.List;
import base_tp_note.Tree;

public class Main {
    public static void main(String[] args){


        Tree test = Tree.new_perfect_tree(4, 2);
        

        
        test.afficher_arbores();
        
        List oui = Tree.liste_inferieure(test, 22);
        List.afficher_list(oui);

       


    }
}
