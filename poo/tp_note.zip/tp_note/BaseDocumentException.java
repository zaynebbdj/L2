public class BaseDocumentException extends Exception {
    
    public BaseDocumentException(String s){
        super(s);
    }

}
